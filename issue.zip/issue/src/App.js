import './App.css';
import { Route, Routes } from 'react-router-dom';
import CreateProject from './components/CreateProject';
import CreateIssue from './components/CreateIssue';
import Sidebar from './components/Sidebar';
import ProjectDetails from './pages/ProjectDetails';
import Navbar from './components/Navbar'
import IssueDetails from './pages/IssueDetails';
import Insights from './pages/Insights';
function App() {
  return (
    <div className="app-container">


      <Navbar />
      <div className="main-content">
        <Sidebar />
        <div className="content">
          <Routes>
            <Route exact path='/' Component={ProjectDetails} />
            <Route exact path='/create-project' Component={CreateProject} />
            <Route exact path='/create-issue' Component={CreateIssue} />
            <Route exact path='/issue-details/:id' Component={IssueDetails}/>
            <Route exact path='/insights' Component={Insights}/>
          </Routes>
        </div>
      </div>
    </div>
  );
}

export default App;
