// CreateIssue.js

import React from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import "@clayui/css/lib/css/atlas.css";
import "../styles/CreateIssue.scss";
import SelectField from "./SelectField"; 
const validationSchema = Yup.object().shape({
  summary: Yup.string().required("Summary is required"),
  type: Yup.string().required("Type is required"),
  project: Yup.string().required("Project is required"),
  description: Yup.string().required("Description is required"),
  priority: Yup.string().required("Priority is required"),
  assignee: Yup.string().required("Assignee is required"),
  tag: Yup.string().required("Tag is required"),
  storyPoints: Yup.number()
    .required("Story Points are required")
    .positive("Story Points must be a positive number"),
});

const CreateIssue = () => {
  const initialValues = {
    summary: "",
    type: "",
    project: "",
    description: "",
    priority: "",
    assignee: "",
    tag: "",
    storyPoints: "",
  };

  const typeOptions = [
    { label: "Type 1", value: "type1" },
    { label: "Type 2", value: "type2" },
    { label: "Type 3", value: "type3" },
  ];

  const projectOptions = [
    { label: "Project 1", value: "project1" },
    { label: "Project 2", value: "project2" },
    { label: "Project 3", value: "project3" },
  ];

  const priorityOptions = [
    { label: "High", value: "high" },
    { label: "Medium", value: "medium" },
    { label: "Low", value: "low" },
  ];

  const assigneeOptions = [
    { label: "Assignee 1", value: "assignee1" },
    { label: "Assignee 2", value: "assignee2" },
    { label: "Assignee 3", value: "assignee3" },
  ];

  const tagOptions = [
    { label: "Tag 1", value: "tag1" },
    { label: "Tag 2", value: "tag2" },
    { label: "Tag 3", value: "tag3" },
  ];

  const handleSubmit = (values, { resetForm }) => {
    console.log(values);
    resetForm({ values: initialValues });
  };

  return (
    <>
      <h1 className="create-issue">Create Issue</h1>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ values, setFieldValue }) => (
          <Form className="form">
            <div className="form-row">
              <div className="form-group col-md-12">
                <label htmlFor="summary">Summary</label>
                <Field
                  type="text"
                  id="summary"
                  name="summary"
                  className="form-control"
                  placeholder="Summary"
                />
                <ErrorMessage
                  name="summary"
                  component="div"
                  className="text-danger"
                />
              </div>
            </div>

            <div className="form-row">
            <SelectField label="Type" name="type" options={typeOptions} />
            <SelectField label="Project" name="project" options={projectOptions} />
            </div>
           

            <div className="form-row">
              <div className="form-group col-md-12">
                <label htmlFor="description">Description</label>
                <Field
                  as="textarea"
                  id="description"
                  name="description"
                  className="form-control"
                  placeholder="Description"
                />
                <ErrorMessage
                  name="description"
                  component="div"
                  className="text-danger"
                />
              </div>
            </div>

            <div className="form-row">
            <SelectField label="Priority" name="priority" options={priorityOptions} />
            <SelectField label="Assignee" name="assignee" options={assigneeOptions} />
            </div>
            <div className="form-row">
            <SelectField label="Tag" name="tag" options={tagOptions} />
            </div>
            <div className="form-row">
              <div className="form-group col-md-6">
                <label htmlFor="storyPoints">Story Points</label>
                <Field
                  type="number"
                  id="storyPoints"
                  name="storyPoints"
                  className="form-control"
                  placeholder="Story Points"
                />
                <ErrorMessage
                  name="storyPoints"
                  component="div"
                  className="text-danger"
                />
              </div>
            </div>

            <div className="form-group form-grp-btn">
              <button type="submit" className="btn btn-primary btn-dark mr-2">
                Submit
              </button>
              <button type="reset" className="btn btn-secondary">
                Reset
              </button>
            </div>
          </Form>
        )}
      </Formik>
    </>
  );
};

export default CreateIssue;
