import React, { useState } from "react";
import { Link } from "react-router-dom";
import image from "../assets/project-board.png";

import "../styles/project-board.scss";
import ProjectCard from "./ProjectCard";
import Button from "@clayui/button";
import DropDown from "@clayui/drop-down";

const ProjectBoard = () => {
  const [items, setItems] = useState([
    {
      id: "123",
      date: "2023-09-28",
      heading: "Sample Heading",
      username: "John Doe",
      priority: "High",
      section: "todo",
      description: "This is a sample task description.",
    },
    {
      id: "124",
      date: "2023-09-29",
      heading: "Another Heading",
      username: "Jane Smith",
      priority: "Medium",
      section: "todo",
      description: "This is another task description.",
    },
    {
      id: "125",
      date: "2023-09-30",
      heading: "Task Three",
      username: "Bob Johnson",
      priority: "Low",
      section: "todo",
      description: "This is the description for Task Three.",
    },
    {
      id: "126",
      date: "2023-10-01",
      heading: "Task Four",
      username: "Alice Brown",
      priority: "High",
      section: "development",
      description: "This is the description for Task Four.",
    },
    {
      id: "127",
      date: "2023-10-02",
      heading: "Development Task",
      username: "Ella White",
      priority: "Medium",
      section: "development",
      description: "Description for the Development Task.",
    },
    {
      id: "128",
      date: "2023-10-03",
      heading: "Dev Work",
      username: "Charlie Green",
      priority: "High",
      section: "development",
      description: "Description for Dev Work task.",
    },
    {
      id: "129",
      date: "2023-10-04",
      heading: "Testing Assignment",
      username: "Grace Taylor",
      priority: "Medium",
      section: "testing",
      description:
        "Description for Testing Description for Testing Assignment Description for Testing Assignment Description for Testing Assignment Assignment.",
    },
    {
      id: "130",
      date: "2023-10-05",
      heading: "Test Task",
      username: "David Davis",
      priority: "Low",
      section: "testing",
      description: "Description for Test Task.",
    },
    {
      id: "131",
      date: "2023-10-06",
      heading: "Completed Job",
      username: "Olivia Lee",
      priority: "High",
      section: "completed",
      description: "Description for Completed Job.",
    },
    {
      id: "132",
      date: "2023-10-07",
      heading: "Finished Task",
      username: "Sophia Clark",
      priority: "Medium",
      section: "completed",
      description: "Description for Finished Task.",
    },
  ]);
  const typeOptions = [
    { label: "Type 1", value: "type1" },
    { label: "Type 2", value: "type2" },
    { label: "Type 3", value: "type3" },
  ];

  const sectionNames = ["todo", "development", "testing", "completed"];

  const len = 1;

  const onDragStart = (e, item) => {
    e.dataTransfer.setData("text/plain", item.id);
  };

  const onDragOver = (e, section) => {
    e.preventDefault();
  };

  const onDrop = (e, section) => {
    e.preventDefault();
    const itemId = e.dataTransfer.getData("text/plain");
    const updatedItems = items.map((item) => {
      if (item.id === itemId) {
        item.section = section;
      }
      return item;
    });
    setItems(updatedItems);
  };

  const renderItemsInSection = (section) => {
    return items
      .filter((item) => item.section === section)
      .map((item) => (
        // <Link to="">
          <ProjectCard key={item.id} item={item} onDragStart={onDragStart} />
          // </Link>
      ));
  };
  const [val, setVal] = useState("First");

  return (
    <div>
      {len === 0 ? (
        <div className="project-board">
          <h2>Welcome to Tracker</h2>
          <p>
            Seems like you haven't created any projects yet.{" "}
            <Link to="/create-project">Click here</Link> to onboard a new
            project.
          </p>
          <div className="board-image">
            <img src={image} alt="project-board" />
          </div>
        </div>
      ) : (
        <>
          <div className="project-borad-header">
            <h1 className="project-details-heading">Project Details</h1>
            <Link className="link" to="/insights">
              VIEW INSIGHTS
            </Link>
          </div>
          <div className="search-project" >
            <div className="select-project">
          <label htmlFor="Project Name">Project Name</label>
                <DropDown
                  trigger={
                    <Button className="find-project">
                      <div>
                        <div>{val}</div> <div>v</div>
                      </div>
                    </Button>
                  }
                  menuElementAttrs={{ className: "dropdown-menu" }}
                >
                  <DropDown.Search placeholder="Type to filter" />

                  <DropDown.ItemList items={typeOptions}>
                    {(item, index) => (
                      <DropDown.Item
                        key={index}
                        onClick={() => setVal(item.label)}
                      >
                        {item.label}
                      </DropDown.Item>
                    )}
                  </DropDown.ItemList>
                </DropDown>
            </div>
            <div className="project-owner select-project" >
                <label htmlFor="Project Owner">Project Name</label>
                <Button className="find-project"><div><div>{val}</div> </div></Button>
            </div>
          </div>
          <p className="start-end-date"> Start Date : 31-01-22 <span>  |  </span> End Date : 31-04-22</p>
<div className="filter-btn">
<div className="select-project">
         
                <DropDown
                  trigger={
                    <Button className="find-project">
                      <div>
                        <div>{val}</div> <div>v</div>
                      </div>
                    </Button>
                  }
                  menuElementAttrs={{ className: "dropdown-menu" }}
                >
                  <DropDown.Search placeholder="Type to filter" />

                  <DropDown.ItemList items={typeOptions}>
                    {(item, index) => (
                      <DropDown.Item
                        key={index}
                        onClick={() => setVal(item.label)}
                      >
                        {item.label}
                      </DropDown.Item>
                    )}
                  </DropDown.ItemList>
                </DropDown>
                <label htmlFor="Project Name">Filter Asignee</label>
            </div>
            <div className="select-project">
         
                <DropDown
                  trigger={
                    <Button className="find-project">
                      <div>
                        <div>{val}</div> <div>v</div>
                      </div>
                    </Button>
                  }
                  menuElementAttrs={{ className: "dropdown-menu" }}
                >
                  <DropDown.Search placeholder="Type to filter" />

                  <DropDown.ItemList items={typeOptions}>
                    {(item, index) => (
                      <DropDown.Item
                        key={index}
                        onClick={() => setVal(item.label)}
                      >
                        {item.label}
                      </DropDown.Item>
                    )}
                  </DropDown.ItemList>
                </DropDown>
                <label htmlFor="Project Name">Filter Priority</label>
            </div>
</div>
          <div className="project-details-container">
            <div className="sections-container">
              {sectionNames.map((sectionName) => (
                <div
                  key={sectionName}
                  className="section"
                  onDragOver={(e) => onDragOver(e, sectionName)}
                  onDrop={(e) => onDrop(e, sectionName)}
                >
                  <h2>{sectionName.toUpperCase()}</h2>
                  {renderItemsInSection(sectionName)}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ProjectBoard;
