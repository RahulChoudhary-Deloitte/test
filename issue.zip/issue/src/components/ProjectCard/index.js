import React from "react";
import '@clayui/css/lib/css/atlas.css'; 
import ClayCard from '@clayui/card';
import './style.scss'
const Card = ({ item, onDragStart}) => {
    const priorityClass = item.priority.toLowerCase(); 

  return (
    <div
    draggable="true"
    onDragStart={(e) => onDragStart(e, item)}
  >
<ClayCard>
        <ClayCard.Body>
      
          <div className="card-row">
            <div className="card-id">{item.id}</div>
            <div className="card-date">{item.date}</div>
          </div>
       
          <div className="card-row">
            <div className="card-heading">{item.heading}</div>
          </div>
            <div className="card-row">
                <span>{item.description}</span>
            </div>
          <div className={`card-row`}>
            <div>
            <div className="user-project-card">
            <img src="https://media.istockphoto.com/id/1406197730/photo/portrait-of-a-young-handsome-indian-man.jpg?s=2048x2048&w=is&k=20&c=lDJRQWb0FtKq9R8biMKvGGZVqn0sVGlUHDPoxR83nWc=" alt="" />
            <h5>Name</h5>
        </div>
            </div>
            <div>
                <p>Priority</p>
            <div className={`card-priority ${priorityClass}`}>
               
              {item.priority}
            </div>
            </div>
          </div>
        </ClayCard.Body>
      </ClayCard>
  </div>
);
};

export default Card;
