import React from 'react'

import './style.scss'
const UserCard = () => {
  return (
    <div className='user-card'>
          <div className="user">
            <h5>Name</h5>
            <img src="https://media.istockphoto.com/id/1406197730/photo/portrait-of-a-young-handsome-indian-man.jpg?s=2048x2048&w=is&k=20&c=lDJRQWb0FtKq9R8biMKvGGZVqn0sVGlUHDPoxR83nWc=" alt="" />
        </div>
    </div>

  )
}

export default UserCard
