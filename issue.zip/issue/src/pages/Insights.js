import React from "react";
import StatusBar from "../components/StatusBar";
import TotalIssues from "../components/TotalIssues";
import './insights.scss'
const Insights = () => {

  return (
    <div className="insights">
      <div className="left">
        <div className="header">
          <div className="title">
            <h1>HU 22.0 React Track</h1>
          </div>
          <p>Total Number of Issues: 08</p>
            <p className="hr"></p>
          <div className="issues-details">
      <TotalIssues title="TO DO" count={0} className="todo" />
      <TotalIssues title="DEVELOPMENT" count={0} className="development" />
      <TotalIssues title="TESTING" count={0} className="testing" />
      <TotalIssues title="COMPLETED" count={0} className="completed" />
    </div>
        </div>
        <div className="status-bar">
          <h3>Status Bar</h3>
          <div>
          <StatusBar todo={25} testing={30} development={60} completed={25} />
          </div>
          <div className="status-sign">
            <div>
                <div className="todo" ></div> TODO
            </div>
            <div>
                <div className="development"></div> DEVELOPMENT
            </div>
            <div>
                <div className="testing"></div> TESTING
            </div>
            <div>
                <div className="completed"></div> COMPLETED
            </div>
          </div>
        </div>
      </div>
      <div className="right">
        <h1>Team Members</h1>
        <p>9 member</p>
        <div>
            <div className="member-info">
                <div className="img">
                <img src="https://media.istockphoto.com/id/1406197730/photo/portrait-of-a-young-handsome-indian-man.jpg?s=2048x2048&w=is&k=20&c=lDJRQWb0FtKq9R8biMKvGGZVqn0sVGlUHDPoxR83nWc=" alt="" />
                <div className="nenber-name">
                    <h1>Rahul Choudhary</h1>
                    <p>Frontend Engineer</p>
                </div>
                </div>
                <p>Owner</p>
            </div>
            <hr />
            <div className="member-info">
                <div className="img">
                <img src="https://media.istockphoto.com/id/1406197730/photo/portrait-of-a-young-handsome-indian-man.jpg?s=2048x2048&w=is&k=20&c=lDJRQWb0FtKq9R8biMKvGGZVqn0sVGlUHDPoxR83nWc=" alt="" />
                <div className="nenber-name">
                    <h1>Rahul Choudhary</h1>
                    <p>Frontend Engineer</p>
                </div>
                </div>
                <p>Owner</p>
            </div>
            <div className="member-info">
                <div className="img">
                <img src="https://media.istockphoto.com/id/1406197730/photo/portrait-of-a-young-handsome-indian-man.jpg?s=2048x2048&w=is&k=20&c=lDJRQWb0FtKq9R8biMKvGGZVqn0sVGlUHDPoxR83nWc=" alt="" />
                <div className="nenber-name">
                    <h1>Rahul Choudhary</h1>
                    <p>Frontend Engineer</p>
                </div>
                </div>
                <p>Owner</p>
            </div>
            <div className="member-info">
                <div className="img">
                <img src="https://media.istockphoto.com/id/1406197730/photo/portrait-of-a-young-handsome-indian-man.jpg?s=2048x2048&w=is&k=20&c=lDJRQWb0FtKq9R8biMKvGGZVqn0sVGlUHDPoxR83nWc=" alt="" />
                <div className="nenber-name">
                    <h1>Rahul Choudhary</h1>
                    <p>Frontend Engineer</p>
                </div>
                </div>
                <p>Owner</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Insights;
