import React from 'react'

const IssueDetails = () => {
  return (
    <div className='issue-details'>
      
    </div>
  )
}

export default IssueDetails
