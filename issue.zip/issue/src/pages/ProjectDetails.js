import React from "react";
import ProjectBoard from '../components/ProjectBoard'

const ProjectDetails = () => {
  
  return (
   <ProjectBoard/>
  );
};

export default ProjectDetails;
